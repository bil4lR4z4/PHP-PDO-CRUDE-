<?php
  	include('config.php');

	if(isset($_GET['show'])){
		$sql = $conn->prepare("SELECT * FROM users ORDER BY id DESC");
		if(isset($_GET['data'])){
			$data = $_GET['data'];
			$sql = $conn->prepare("SELECT * FROM users WHERE name LIKE '%$data%' OR email LIKE '%$data%' ORDER BY id DESC");
		}
		$sql->execute();

		if($sql->rowCount() > 0){
			$no =1;
			while($row = $sql->fetch(PDO::FETCH_ASSOC)){
				echo "<tr>
						<td>{$no}</td>
						<td>{$row['name']}</td>
						<td>{$row['email']}</td>
						<td><button class='btn btn-danger dlt' data-id='{$row['id']}'>Delete</button>
						<button class='btn btn-success edit' data-id='{$row['id']}' data-name='{$row['name']}' data-email='{$row['email']}' data-bs-toggle='modal' data-bs-target='#editmodal'>Edit</button></td>
					  </tr>";
				$no++;
			}
		}else{
			echo "<tr><td colspan='4' class='text-center'>Data Not Found!</td></tr>";
		}
	}
	if(isset($_GET['insert'])){
		$name = $_POST['name'];
		$email = $_POST['email'];

		$sql = $conn->prepare("INSERT INTO `users`(`name`, `email`) VALUES (?,?)");

		if($sql->execute([$name, $email])){
			echo json_encode(['status' => 'success']);
		}else{
			echo json_encode(['status' => 'error']);
		}
	}

	if(isset($_GET['dlt'])){
		$id = $_POST['id'];
		$sql = $conn->prepare("DELETE FROM `users` WHERE id = ?");
		if($sql->execute([$id])){
			echo json_encode(['status' => 'success']);
		}else{
			echo json_encode(['status' => 'error']);
		}
	}

	if(isset($_GET['update'])){
		$name = $_POST['name'];
		$email = $_POST['email'];
		$id = $_POST['id'];
		
		$sql = $conn->prepare("UPDATE `users` SET `name`=?, `email`=? WHERE `id` = ?");
		if($sql->execute([$name, $email, $id])){
			echo json_encode(['status' => 'success']);
		}else{
			echo json_encode(['status' => 'error']);
		}
	}


?>