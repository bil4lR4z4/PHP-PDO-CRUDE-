<?php
$db = "mysql:host=localhost;dbname=basic_crude";
$username = "root";
$password = "";

$conn = new PDO($db, $username, $password);

?>