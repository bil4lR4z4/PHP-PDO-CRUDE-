<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Crude Application</title>
</head>

	<link rel="stylesheet" href="css/bootstrap.css">
<body>
	
	<div class="container">
	  	<div class="row row-cols-1">
			<div class="text-bg-secondary py-3">
				<h1 class="text-center">Basic PHP CRUDE</h1>
				<div class="d-flex justify-content-between">
				  	<button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#addmodal">ADD USER</button>
					<form action="">
						<input type="search" class="form-control shadow-none search">
					</form>
				</div>
			</div>
			<div class="table-responsive p-0">
				<table class="table table-dark">
					<thead>
						<tr>
							<th>S-No</th>
							<th>Name</th>
							<th>Email</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
<div class="modal fade" id="addmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="">
        	<div class="form-floating mb-3">
				<input type="text" class="form-control focus-ring name" placeholder="">
				<label>Enter Name</label>
			</div>
			<div class="form-floating">
				<input type="email" class="form-control focus-ring email" placeholder="">
				<label>Enter Email</label>
			</div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary addData">Save User</button>
      </div>
    </div>
  </div>
</div>
	
<!--Edit Modal-->
<div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="">
        	<div class="form-floating mb-3">
				<input type="text" class="form-control focus-ring uname" placeholder="">
				<label>Enter Name</label>
			</div>
			<div class="form-floating">
				<input type="email" class="form-control focus-ring uemail" placeholder="">
				<label>Enter Email</label>
			</div>
			<input type="hidden" class="uid">
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary updateData">Update User</button>
      </div>
    </div>
  </div>
</div>
	
	<div class="toast align-items-center text-bg-dark successMsg border-0 position-absolute bottom-0 ms-3 mb-3" role="alert" aria-live="assertive" aria-atomic="true">
	  <div class="d-flex">
		<div class="toast-body">
		
		</div>
		<button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
	  </div>
	</div>
	<div class="toast align-items-center text-bg-danger errorMsg border-0 position-absolute bottom-0 ms-3 mb-3" role="alert" aria-live="assertive" aria-atomic="true">
	  <div class="d-flex">
		<div class="toast-body">
		  
		</div>
		<button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
	  </div>
	</div>
	<script src="js/bootstrap.js"></script>
	<script src="js/jquery.js"></script>
	<script>
		$(document).ready(function(){
			$(".name , .email").on("input", function(){
				$(this).removeClass("focus-ring-danger border-danger");
			})
			
			function loadData(search){
				$.ajax({
					url : "php/php.php?show",
					data : {data : search},
					success: function(data){
						 $('tbody').html(data);
					}
				})
			}
			loadData()
		  	$(".addData").on("click", function(){
			  var name = $(".name").val().trim();
			  var email = $(".email").val().trim();
			  var emailPtn =  /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; 
			  if(name == ''){
				  $(".name").focus().addClass("focus-ring-danger border-danger")
			  }else if(email == "" || !emailPtn.test(email)){
				  $(".email").focus().addClass("focus-ring-danger border-danger");
			  }else{
				  $.ajax({
					  url : "php/php.php?insert",
					  type : "POST",
					  data : {
						  name : name,
						  email : email,
					  },
					  success: function(data){
						  data = JSON.parse(data);
						  if(data.status == 'error'){
							  $(".errorMsg .toast-body").text("Server Error!").addClass('show');
							  setTimeout(function(){
								  $(".errorMsg").removeClass('show');
							  },4000);
							  loadData()
						  }else if(data.status == 'success'){
							  $(".successMsg .toast-body").text("User Add Successfully");
							  $(".successMsg").addClass('show');
							  setTimeout(function(){
								  $(".successMsg").removeClass('show');
							  },4000);
							  loadData();
							  $('form').trigger('reset');
							  $('#addmodal').modal('hide')
						  }
					  }
				  })
			  }
		  })
			
		  	$(document).on("click", '.dlt', function(){
				var id = $(this).data('id');
				$.ajax({
					  url : "php/php.php?dlt",
					  type : "POST",
					  data : {
						  id : id,
					  },
					  success: function(data){
						  data = JSON.parse(data);
						  if(data.status == 'error'){
							  $(".errorMsg .toast-body").text("User Not Delete!");
							  $(".errorMsg").addClass('show');
							  setTimeout(function(){
								  $(".errorMsg").removeClass('show');
							  },4000);
						  }else if(data.status == 'success'){
							  $(".successMsg .toast-body").text("User Delete Successfully.");
							  $(".successMsg").addClass('show');
							  setTimeout(function(){
								  $(".successMsg").removeClass('show');
							  },4000);
							  loadData();
						  }
					  }
				})
			})
			
			$(document).on("click", '.edit', function(){
				var id = $(this).data('id');
				var name = $(this).data('name');
				var email = $(this).data('email');
				
				$(".uname").val(name);
				$(".uemail").val(email);
				$(".uid").val(id);
			})
			
			$(document).on("click", ".updateData", function(){
				var id = $(".uid").val();
				var name = $(".uname").val();
				var email = $(".uemail").val();
				
				var emailPtn =  /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				if(name == ''){
				   $(".uname").focus().addClass("focus-ring-danger border-danger")
				}else if(email == "" || !emailPtn.test(email)){
				   $(".uemail").focus().addClass("focus-ring-danger border-danger");
				}else{
					$.ajax({
					  url : "php/php.php?update",
					  type : "POST",
					  data : {
						  name : name,
						  email : email,
						  id : id,
					  },
					  success: function(data){
						  data = JSON.parse(data);
						  if(data.status == 'error'){
							  $(".errorMsg .toast-body").text("Server Error.Try Again.");
							  $(".errorMsg").addClass('show');
							  setTimeout(function(){
								  $(".errorMsg").removeClass('show');
							  },4000);
							  loadData();
						  }else if(data.status == 'success'){
							  $(".successMsg .toast-body").text("User Update Successfully.");
							  $(".successMsg").addClass('show');
							  setTimeout(function(){
								  $(".successMsg").removeClass('show');
							  },4000);
							  loadData();
							  $('#editmodal').modal('hide')
						  }
					  }
				  })
				}
			})
			
			$(".search").on("input", function(){
				var search = $(this).val();
				loadData(search);
			})
		})
	</script>
</body>
</html>